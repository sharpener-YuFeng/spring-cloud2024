package com.atguigu.cloud.service;

import com.atguigu.cloud.entities.Storage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author qkzzfd
* @description 针对表【t_storage】的数据库操作Service
* @createDate 2024-10-02 16:02:21
*/
public interface StorageService extends IService<Storage> {
    /**
     * 扣减库存
     */
    void decrease(Long productId, Integer count);
}
