package com.atguigu.cloud.mapper;

import com.atguigu.cloud.entities.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface OrderMapper extends BaseMapper<Order> {
}