package com.atguigu.cloud;

import java.time.ZonedDateTime;

/**
 * @Author yufeng
 * @Create 2024/9/12 上午10:52
 */
public class Main {
    public static void main(String[] args) {
        ZonedDateTime now = ZonedDateTime.now(); // 默认时区
        System.out.println(now);
    }
}