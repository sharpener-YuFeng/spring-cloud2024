package com.atguigu.cloud.service;

import com.atguigu.cloud.entities.Order;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author yufeng
 * @Create 2024/10/2 上午10:06
 */
public interface OrderService extends IService<Order> {

    /**
     * 创建订单
     */
    void create(Order order);

}