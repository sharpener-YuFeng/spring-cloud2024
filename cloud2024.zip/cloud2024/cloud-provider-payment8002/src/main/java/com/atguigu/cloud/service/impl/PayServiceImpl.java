package com.atguigu.cloud.service.impl;

import com.atguigu.cloud.entities.Pay;
import com.atguigu.cloud.mapper.PayMapper;
import com.atguigu.cloud.service.PayService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author yufeng
 * @Create 2024/9/9 下午9:30
 */
@Service
public class PayServiceImpl implements PayService {
    @Resource
    private PayMapper payMapper;

    @Override
    public int add(Pay pay) {
        return payMapper.insert(pay);
    }

    @Override
    public int delete(Integer id) {
        return payMapper.deleteById(id);
    }

    @Override
    public int update(Pay pay) {
        return payMapper.updateById(pay);
    }

    @Override
    public Pay getById(Integer id) {
        return payMapper.selectById(id);
    }

    @Override
    public List<Pay> getAll() {
        return payMapper.selectList(null);
    }
}
