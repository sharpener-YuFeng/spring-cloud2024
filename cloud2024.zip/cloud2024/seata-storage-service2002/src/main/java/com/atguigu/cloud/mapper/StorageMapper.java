package com.atguigu.cloud.mapper;

import com.atguigu.cloud.entities.Storage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author qkzzfd
* @description 针对表【t_storage】的数据库操作Mapper
* @createDate 2024-10-02 16:02:21
* @Entity com.atguigu.cloud.entities.Storage
*/
public interface StorageMapper extends BaseMapper<Storage> {
    /**
     * 扣减库存
     */
    void decrease(@Param("productId") Long productId, @Param("count") Integer count);
}




