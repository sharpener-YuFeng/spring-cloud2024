package com.atguigu.cloud.service;

import com.atguigu.cloud.entities.Pay;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * @Author yufeng
 * @Create 2024/9/9 下午9:25
 */
public interface PayService extends IService<Pay> {
    int add(Pay pay);
    int delete(Integer id);
    int update(Pay pay);
    Pay getById(Integer id);
    List<Pay> getAll();
}
