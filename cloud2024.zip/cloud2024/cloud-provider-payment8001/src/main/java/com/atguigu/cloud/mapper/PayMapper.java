package com.atguigu.cloud.mapper;

import com.atguigu.cloud.entities.Pay;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface PayMapper extends BaseMapper<Pay> {
}