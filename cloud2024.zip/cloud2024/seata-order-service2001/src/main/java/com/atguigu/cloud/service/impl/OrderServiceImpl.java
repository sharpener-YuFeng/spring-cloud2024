package com.atguigu.cloud.service.impl;

import com.atguigu.cloud.apis.AccountFeignApi;
import com.atguigu.cloud.apis.StorageFeignApi;
import com.atguigu.cloud.entities.Order;
import com.atguigu.cloud.mapper.OrderMapper;
import com.atguigu.cloud.service.OrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.seata.core.context.RootContext;
import io.seata.spring.annotation.GlobalTransactional;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @Author yufeng
 * @Create 2024/10/2 上午10:07
 */
@Service
@Slf4j
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {
    @Resource
    private OrderMapper orderMapper;

    // 订单微服务通过OpenFeign去调用库存微服务
    @Resource
    private StorageFeignApi storageFeignApi;

    // 订单微服务通过OpenFeign去调用账户微服务
    @Resource
    private AccountFeignApi accountFeignApi;

    @Override
    @GlobalTransactional(name = "zzyy-create-order",rollbackFor = Exception.class) // AT
    public void create(Order order) {
        // xid全局事务id的检查，重要！
        String xid = RootContext.getXID();
        // 1.新建订单
        log.info("------开始新建订单: " + "\t" + "xid: " + xid);
        // 订单新建时默认初始订单状态是0
        order.setStatus(0);
        int result = orderMapper.insert(order);
        // 插入订单成功后
        if(result > 0) {
            log.info("------>新建订单成功，order对象信息: " + order + "\n");
            // 2.扣减库存
            log.info("------>订单微服务开始调用Storage库存，做扣减count");
            storageFeignApi.decrease(order.getProductId(), order.getCount());
            // 3.扣减账户余额
            log.info("------>订单微服务开始调用Account账号，做扣减资金");
            accountFeignApi.decrease(order.getUserId(), order.getMoney());
            log.info("------>订单微服务结束调用Account账号,扣减资金完成\n");
            // 4.修改订单状态
            log.info("------>修改订单状态");
            order.setStatus(1);
            int updateResult = orderMapper.updateById(order);
            log.info("------>修改订单状态完成" + "\t" + updateResult);
            log.info("------>order info：" + order);
        }
        System.out.println();
        log.info("------>结束新建订单：" + "\t" + "xid: " + xid);
    }
}
